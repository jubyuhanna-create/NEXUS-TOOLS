/* ═══════════════════════════════════════════
   NEXUS TOOLS — password-generator.js
   ═══════════════════════════════════════════ */

const UPPER   = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const LOWER   = 'abcdefghijklmnopqrstuvwxyz';
const NUMBERS = '0123456789';
const SYMBOLS = '!@#$%^&*()_+-=[]{}|;:,.<>?';

function updateLengthDisplay() {
  const el = document.getElementById('lengthDisplay');
  if (el) el.textContent = document.getElementById('lengthSlider').value;
}

function generatePassword() {
  const len   = parseInt(document.getElementById('lengthSlider').value);
  const upper = document.getElementById('useUpper').checked;
  const lower = document.getElementById('useLower').checked;
  const nums  = document.getElementById('useNumbers').checked;
  const syms  = document.getElementById('useSymbols').checked;

  let charset = '';
  const required = [];
  if (upper) { charset += UPPER;   required.push(UPPER); }
  if (lower) { charset += LOWER;   required.push(LOWER); }
  if (nums)  { charset += NUMBERS; required.push(NUMBERS); }
  if (syms)  { charset += SYMBOLS; required.push(SYMBOLS); }

  if (!charset) { showToast('Select at least one character type'); return; }

  let password = '';
  required.forEach(set => {
    password += set[crypto.getRandomValues(new Uint32Array(1))[0] % set.length];
  });

  const arr = new Uint32Array(len - required.length);
  crypto.getRandomValues(arr);
  for (let i = 0; i < arr.length; i++) password += charset[arr[i] % charset.length];

  // Fisher-Yates shuffle
  password = password.split('');
  for (let i = password.length - 1; i > 0; i--) {
    const j = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1);
    [password[i], password[j]] = [password[j], password[i]];
  }
  password = password.join('');

  document.getElementById('passwordText').textContent = password;
  updateStrength(password);
}

function updateStrength(pwd) {
  let score = 0;
  if (pwd.length >= 12) score++;
  if (pwd.length >= 20) score++;
  if (/[A-Z]/.test(pwd) && /[a-z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[^A-Za-z0-9]/.test(pwd)) score++;
  score = Math.min(score, 4);

  const labels  = ['', 'Weak', 'Fair', 'Good', 'Strong'];
  const classes = ['', 'active-weak', 'active-fair', 'active-good', 'active-strong'];
  for (let i = 1; i <= 4; i++) {
    const bar = document.getElementById('sb' + i);
    if (bar) bar.className = 'strength-bar' + (i <= score ? ' ' + classes[score] : '');
  }
  const lbl = document.getElementById('strengthLabel');
  if (lbl) lbl.textContent = labels[score] || '—';
}

function copyPassword() {
  const pwd = document.getElementById('passwordText').textContent;
  if (pwd === 'Click generate to create a password') { showToast('Generate a password first'); return; }
  navigator.clipboard.writeText(pwd).then(() => showToast('Password copied!'));
}

// Auto-generate on load
document.addEventListener('DOMContentLoaded', generatePassword);
