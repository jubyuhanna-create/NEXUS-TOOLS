/* ═══════════════════════════════════════════
   NEXUS TOOLS — word-counter.js
   ═══════════════════════════════════════════ */

const statCache = {};

function updateWordStats() {
  const text = document.getElementById('wordInput').value;
  const words     = text.trim() === '' ? 0 : text.trim().split(/\s+/).filter(w => w.length > 0).length;
  const chars     = text.length;
  const sentences = text.trim() === '' ? 0 : text.split(/[.!?]+/).filter(s => s.trim().length > 0).length;
  const paragraphs= text.trim() === '' ? 0 : text.split(/\n\s*\n/).filter(p => p.trim().length > 0).length;
  const readingTime = Math.ceil(words / 200);

  setStat('wordCount',  words);
  setStat('charCount',  chars);
  setStat('sentenceCount', sentences);

  const rt = document.getElementById('readTime');
  if (rt) rt.textContent = readingTime < 1 ? '<1m' : readingTime + 'm';
}

function setStat(id, val) {
  const el = document.getElementById(id);
  if (!el) return;
  if (statCache[id] === val) return;
  statCache[id] = val;
  el.textContent = val.toLocaleString();
}

function clearWordCounter() {
  document.getElementById('wordInput').value = '';
  updateWordStats();
}

function copyWordText() {
  const text = document.getElementById('wordInput').value;
  if (!text) { showToast('Nothing to copy'); return; }
  navigator.clipboard.writeText(text).then(() => showToast('Text copied!'));
}

document.addEventListener('DOMContentLoaded', updateWordStats);
