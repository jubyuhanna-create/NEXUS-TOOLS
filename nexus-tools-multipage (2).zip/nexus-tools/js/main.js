/* ═══════════════════════════════════════════
   NEXUS TOOLS — main.js (shared)
   ═══════════════════════════════════════════ */

// ─── TOAST ───────────────────────────────────
function showToast(msg, color) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  if (color) t.style.color = color;
  t.classList.add('show');
  setTimeout(() => { t.classList.remove('show'); if (color) t.style.color = ''; }, 2400);
}

// ─── HAMBURGER NAV ────────────────────────────
(function() {
  const btn  = document.getElementById('hamburger');
  const menu = document.getElementById('mobileMenu');
  if (!btn || !menu) return;
  btn.addEventListener('click', () => {
    menu.classList.toggle('open');
    const open = menu.classList.contains('open');
    btn.setAttribute('aria-expanded', open);
  });
  // close on outside click
  document.addEventListener('click', e => {
    if (!btn.contains(e.target) && !menu.contains(e.target)) menu.classList.remove('open');
  });
})();

// ─── ACTIVE NAV LINK ──────────────────────────
(function() {
  const path = window.location.pathname.replace(/\/$/, '') || '/index.html';
  document.querySelectorAll('.nav-link').forEach(a => {
    const href = a.getAttribute('href');
    if (!href) return;
    const linkPath = href.replace(/\/$/, '');
    if (path.endsWith(linkPath) || (path.endsWith('/') && linkPath === '/index.html')) {
      a.classList.add('active');
    }
  });
})();

// ─── SCROLL REVEAL ────────────────────────────
(function() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.style.animationPlayState = 'running'; obs.unobserve(e.target); }
    });
  }, { threshold: 0.1 });
  document.querySelectorAll('.tool-card, .blog-card, .value-card, .team-card').forEach(el => {
    el.style.animationPlayState = 'paused';
    obs.observe(el);
  });
})();
