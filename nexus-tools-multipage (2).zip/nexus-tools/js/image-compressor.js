/* ═══════════════════════════════════════════
   NEXUS TOOLS — image-compressor.js
   ═══════════════════════════════════════════ */

let originalFile = null;
let compressedBlob = null;

const dropZone      = document.getElementById('dropZone');
const imageInput    = document.getElementById('imageInput');
const qualitySlider = document.getElementById('qualitySlider');
const qualityVal    = document.getElementById('qualityVal');

if (qualitySlider) {
  qualitySlider.addEventListener('input', () => {
    qualityVal.textContent = qualitySlider.value + '%';
  });
}

if (dropZone) {
  dropZone.addEventListener('dragover',  e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
  dropZone.addEventListener('dragleave', ()  => dropZone.classList.remove('drag-over'));
  dropZone.addEventListener('drop', e => {
    e.preventDefault(); dropZone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) { originalFile = file; showOriginalPreview(file); }
  });
}

if (imageInput) {
  imageInput.addEventListener('change', () => {
    if (imageInput.files[0]) { originalFile = imageInput.files[0]; showOriginalPreview(originalFile); }
  });
}

function showOriginalPreview(file) {
  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById('originalPreview').src = e.target.result;
    document.getElementById('originalSize').textContent = formatBytes(file.size);
    document.getElementById('imageResult').style.display = 'block';
    document.getElementById('compressedPreview').src = '';
    document.getElementById('compressedSize').textContent = '—';
    document.getElementById('sizeReduction').textContent = '— Compress to see results';
    const dl = document.getElementById('downloadBtn');
    if (dl) dl.removeAttribute('href');
  };
  reader.readAsDataURL(file);
}

function compressImage() {
  if (!originalFile) { showToast('Please select an image first'); return; }
  const quality = parseInt(qualitySlider.value) / 100;
  const reader  = new FileReader();
  reader.onload = e => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width  = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      const mimeType = 'image/jpeg';
      function tryCompress(q) {
        canvas.toBlob(blob => {
          if (blob.size >= originalFile.size && q > 0.05) { tryCompress(Math.max(q - 0.1, 0.05)); return; }
          compressedBlob = blob;
          const url = URL.createObjectURL(blob);
          document.getElementById('compressedPreview').src = url;
          document.getElementById('compressedSize').textContent = formatBytes(blob.size);
          const saved      = originalFile.size - blob.size;
          const reduction  = ((saved / originalFile.size) * 100).toFixed(1);
          const usedQ      = Math.round(q * 100);
          document.getElementById('sizeReduction').textContent = saved > 0
            ? `✓ REDUCED BY ${reduction}% — SAVED ${formatBytes(saved)} — QUALITY: ${usedQ}%`
            : `⚠ Could not reduce further — image may already be highly compressed.`;
          const dl = document.getElementById('downloadBtn');
          if (dl) { dl.href = url; dl.download = `compressed_${Date.now()}.jpg`; }
          qualitySlider.value = usedQ;
          qualityVal.textContent = usedQ + '%';
        }, mimeType, q);
      }
      tryCompress(quality);
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(originalFile);
}

function resetImageTool() {
  originalFile = null; compressedBlob = null;
  if (imageInput) imageInput.value = '';
  document.getElementById('imageResult').style.display = 'none';
  document.getElementById('originalPreview').src = '';
  document.getElementById('compressedPreview').src = '';
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}
